For the submission in electronic format, a ZIP file should be created that contains all the material. 

The name of this file must be of the form

p4_gggg_nn_surname1_surname2.zip,

where

gggg: Group number: (1311, 1312, 1391, etc.). 
nn: lab team number with two digits (01, 02, 03, etc.).
surname1: First surname of member 1 of the lab team.
surname2: First surname of member 2 of the lab team.

The members of the lab team must appear in alphabetical order. 

Examples:

p4_1311_01_delval_sanchez.zip (lab assignment 4 of team 01 in group 1311).
p4_1392_18_bellogin_suarez.zip (la assignment 4 of team 18 in group 1392).


